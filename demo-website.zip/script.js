function showAlert() {
  alert("Chúc mừng bạn đã nhấn nút!");
}
